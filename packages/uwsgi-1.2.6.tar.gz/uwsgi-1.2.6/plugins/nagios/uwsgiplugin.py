
NAME='nagios'
CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['nagios']
