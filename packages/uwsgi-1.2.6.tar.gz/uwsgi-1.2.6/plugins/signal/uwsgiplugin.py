
NAME='signal'
CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['signal_plugin']
