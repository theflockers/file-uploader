
NAME='probeconnect'
CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['connectprobe']
